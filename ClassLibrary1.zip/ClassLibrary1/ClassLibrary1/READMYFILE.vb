﻿Imports BricscadApp
Imports BricscadDb
Imports System.IO
Imports Teigha
Imports Teigha.DatabaseServices
Imports Teigha.Runtime
Imports Bricscad.EditorInput
Imports Bricscad.ApplicationServices
Imports System.Runtime.InteropServices
Imports Teigha.Geometry
Imports Bricscad.Runtime

Public Class Class1
    <LispFunction("ReadFile")>
    Public Shared Function ReadFile(ByVal args As ResultBuffer)
        Dim Filename As String = CType(args.AsArray()(0).Value, String)
        Dim Delimeter As String = CType(args.AsArray()(1).Value, String)
        Dim Format As String = CType(args.AsArray()(2).Value, String)
        Dim Etype As String = CType(args.AsArray()(3).Value, String)

        Try
            Dim streamreader As StreamReader = New StreamReader(Filename)
            Dim extreader = Path.GetExtension(Filename)
            Dim v

            'Determine  N,E,Z
            Dim North, East, Zelevation
            If Format.Contains("N") Then
                North = Format.IndexOf("N")
            End If
            If Format.Contains("E") Then
                East = Format.IndexOf("E")
            End If
            If Format.Contains("Z") Then
                Zelevation = Format.IndexOf("Z")
            End If

            Dim count = 0
            Do Until streamreader.ReadLine Is Nothing
                count = count + 1
            Loop
            streamreader = New StreamReader(Filename)
            Dim rb As New ResultBuffer()

            If Etype = "Point" Then
                For w = 1 To count - 1
                    v = streamreader.ReadLine()
                    rb.Add(New TypedValue(LispDataType.Text, v))
                    Dim point(2) As Double
                    point = {v.Split(Delimeter)(East), v.Split(Delimeter)(North), v.Split(Delimeter)(Zelevation)}
                    Dim doc As Document = Application.DocumentManager.MdiActiveDocument
                    Dim db As Database = doc.Database
                    Using trans As Transaction = db.TransactionManager.StartTransaction()
                        Try
                            Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

                            Dim btr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite), BlockTableRecord)

                            Dim Po As New Point3d(point(0), point(1), point(2))

                            Using pointa As New DBPoint(Po)
                                btr.AppendEntity(pointa)
                                trans.AddNewlyCreatedDBObject(pointa, True)
                            End Using

                            trans.Commit()
                        Catch ex As System.Exception
                            doc.Editor.WriteMessage("Error encountered: " & ex.Message)
                            trans.Abort()
                        End Try
                    End Using
                Next
            End If
            Return rb

        Catch ex As Exception
            MsgBox("Error Occured:" & ex.Message)
        End Try
    End Function

End Class


