﻿Imports BricscadApp
Imports BricscadDb
Imports System.IO
Imports Teigha
Imports Teigha.DatabaseServices
Imports Teigha.Runtime
Imports Bricscad.EditorInput
Imports Bricscad.ApplicationServices
Imports System.Runtime.InteropServices
Imports Teigha.Geometry
Public Class Class1
    <LispFunction("ReadFile")>
    Public Shared Function ReadFile(ByVal args As ResultBuffer)
        Dim Filename As String = CType(args.AsArray()(0).Value, String)
        Dim Delimeter As String = CType(args.AsArray()(1).Value, String)
        Dim Format As String = CType(args.AsArray()(2).Value, String)
        Dim Etype As String = CType(args.AsArray()(3).Value, String)

        Try
            'Public Shared Function ReadFile(ByRef Filename As String, ByRef Format As String, ByRef EntityType As String)
            Dim streamreader As StreamReader = New StreamReader(Filename)
            Dim extreader = Path.GetExtension(Filename)
            Dim space = " "
            'Dim delimeterreader As Char() = {";", "|", "\t", ",", space}
            'Dim delimeter
            Dim pointNo
            If extreader = ".csv" Then
                Dim v = streamreader.ReadLine()
                Dim count = 0
                Do Until streamreader.ReadLine Is Nothing
                    count = count + 1
                Loop
                streamreader = New StreamReader(Filename)
                If Format = "PNEZD" Then
                    If Etype = "Point" Then
                        For w = 0 To count - 1
                            v = streamreader.ReadLine()
                            pointNo = v.Split(Delimeter)(0)
                            Dim point(2) As Double
                            point = {v.Split(Delimeter)(2), v.Split(Delimeter)(1), v.Split(Delimeter)(3)}
                            Dim doc As Document = Application.DocumentManager.MdiActiveDocument
                            Dim db As Database = doc.Database

                            Using trans As Transaction = db.TransactionManager.StartTransaction()
                                Try
                                    Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

                                    Dim btr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite), BlockTableRecord)

                                    Dim Po As New Point3d(point(0), point(1), point(2))

                                    Using pointa As New DBPoint(Po)
                                        btr.AppendEntity(pointa)
                                        trans.AddNewlyCreatedDBObject(pointa, True)
                                    End Using

                                    trans.Commit()
                                Catch ex As System.Exception
                                    doc.Editor.WriteMessage("Error encountered: " & ex.Message)
                                    trans.Abort()
                                End Try
                            End Using
                        Next
                    End If
                ElseIf Format = "PNEZIID" Then
                    If Etype = "Point" Then
                        For w = 0 To count - 1
                            v = streamreader.ReadLine()
                            pointNo = v.Split(Delimeter)(0)
                            Dim point(2) As Double
                            point = {v.Split(Delimeter)(2), v.Split(Delimeter)(1), v.Split(Delimeter)(3)}
                            Dim doc As Document = Application.DocumentManager.MdiActiveDocument
                            Dim db As Database = doc.Database

                            Using trans As Transaction = db.TransactionManager.StartTransaction()
                                Try
                                    Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

                                    Dim btr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite), BlockTableRecord)

                                    Dim Po As New Point3d(point(0), point(1), point(2))

                                    Using pointa As New DBPoint(Po)
                                        btr.AppendEntity(pointa)
                                        trans.AddNewlyCreatedDBObject(pointa, True)
                                    End Using

                                    trans.Commit()
                                Catch ex As System.Exception
                                    doc.Editor.WriteMessage("Error encountered: " & ex.Message)
                                    trans.Abort()
                                End Try
                            End Using
                        Next
                    End If

                ElseIf Format = "NEZ" Then
                    If Etype = "Point" Then
                        For w = 0 To count - 1
                            v = streamreader.ReadLine()
                            'pointNo = v.Split(Delimeter)(0)
                            Dim point(2) As Double
                            point = {v.Split(Delimeter)(0), v.Split(Delimeter)(1), v.Split(Delimeter)(2)}
                            Dim doc As Document = Application.DocumentManager.MdiActiveDocument
                            Dim db As Database = doc.Database

                            Using trans As Transaction = db.TransactionManager.StartTransaction()
                                Try
                                    Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

                                    Dim btr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite), BlockTableRecord)

                                    Dim Po As New Point3d(point(0), point(1), point(2))

                                    Using pointa As New DBPoint(Po)
                                        btr.AppendEntity(pointa)
                                        trans.AddNewlyCreatedDBObject(pointa, True)
                                    End Using

                                    trans.Commit()
                                Catch ex As System.Exception
                                    doc.Editor.WriteMessage("Error encountered: " & ex.Message)
                                    trans.Abort()
                                End Try
                            End Using
                        Next
                    End If

                ElseIf Format = "NEZD" Then
                    If Etype = "Point" Then
                        For w = 0 To count - 1
                            v = streamreader.ReadLine()
                            'pointNo = v.Split(Delimeter)(0)
                            Dim point(2) As Double
                            point = {v.Split(Delimeter)(0), v.Split(Delimeter)(1), v.Split(Delimeter)(2)}
                            Dim doc As Document = Application.DocumentManager.MdiActiveDocument
                            Dim db As Database = doc.Database

                            Using trans As Transaction = db.TransactionManager.StartTransaction()
                                Try
                                    Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

                                    Dim btr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite), BlockTableRecord)

                                    Dim Po As New Point3d(point(0), point(1), point(2))

                                    Using pointa As New DBPoint(Po)
                                        btr.AppendEntity(pointa)
                                        trans.AddNewlyCreatedDBObject(pointa, True)
                                    End Using

                                    trans.Commit()
                                Catch ex As System.Exception
                                    doc.Editor.WriteMessage("Error encountered: " & ex.Message)
                                    trans.Abort()
                                End Try
                            End Using
                        Next
                    End If

                ElseIf Format = "IIIPENZD" Then
                    If Etype = "Point" Then
                        For w = 0 To count - 1
                            v = streamreader.ReadLine()
                            'pointNo = v.Split(Delimeter)(0)
                            Dim point(2) As Double
                            point = {v.Split(Delimeter)(4), v.Split(Delimeter)(5), v.Split(Delimeter)(6)}
                            Dim doc As Document = Application.DocumentManager.MdiActiveDocument
                            Dim db As Database = doc.Database

                            Using trans As Transaction = db.TransactionManager.StartTransaction()
                                Try
                                    Dim bt As BlockTable = CType(trans.GetObject(db.BlockTableId, OpenMode.ForRead), BlockTable)

                                    Dim btr As BlockTableRecord = CType(trans.GetObject(bt(BlockTableRecord.ModelSpace), OpenMode.ForWrite), BlockTableRecord)

                                    Dim Po As New Point3d(point(0), point(1), point(2))

                                    Using pointa As New DBPoint(Po)
                                        btr.AppendEntity(pointa)
                                        trans.AddNewlyCreatedDBObject(pointa, True)
                                    End Using

                                    trans.Commit()
                                Catch ex As System.Exception
                                    doc.Editor.WriteMessage("Error encountered: " & ex.Message)
                                    trans.Abort()
                                End Try
                            End Using
                        Next
                    End If

                End If
            End If

        Catch ex As Exception
            MsgBox("Error Occured:" & ex.Message)
        End Try

    End Function

End Class

